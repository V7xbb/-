import { create } from "zustand";
import {
  CATEGORY_IDS,
  type CategoryId,
  type CardShape,
  type Quote,
  dailyStartIndex,
  isCardShape,
  quotesByCategory,
} from "@/lib/quotes";

export type TabId = "feed" | "studio" | "favorites" | "topics";

const FAV_KEY = "qabas-favorites";
const CUSTOM_KEY = "qabas-custom";

function readFavorites(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FAV_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((id): id is string => typeof id === "string");
  } catch {
    return [];
  }
}

function writeFavorites(ids: string[]) {
  window.localStorage.setItem(FAV_KEY, JSON.stringify(ids));
}

function readCustom(): Quote[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(CUSTOM_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const cats = new Set<string>(CATEGORY_IDS);
    const out: Quote[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== "object") continue;
      const q = item as Record<string, unknown>;
      if (typeof q.id !== "string" || typeof q.text !== "string") continue;
      if (typeof q.author !== "string") continue;
      if (typeof q.category !== "string" || !cats.has(q.category)) continue;
      if (typeof q.shape !== "string" || !isCardShape(q.shape)) continue;
      out.push({
        id: q.id,
        text: q.text.slice(0, 220),
        author: q.author.slice(0, 60),
        category: q.category as CategoryId,
        shape: q.shape as CardShape,
        custom: true,
      });
    }
    return out;
  } catch {
    return [];
  }
}

function writeCustom(quotes: Quote[]) {
  window.localStorage.setItem(CUSTOM_KEY, JSON.stringify(quotes));
}

type QuotesState = {
  tab: TabId;
  category: CategoryId | "all";
  index: number;
  favorites: string[];
  customQuotes: Quote[];
  toast: string | null;
  hydrated: boolean;
  setTab: (tab: TabId) => void;
  setCategory: (category: CategoryId | "all") => void;
  hydrate: () => void;
  next: () => void;
  prev: () => void;
  goTo: (id: string) => void;
  shuffle: () => void;
  toggleFavorite: (id: string) => void;
  saveQuote: (input: {
    id?: string;
    text: string;
    author: string;
    category: CategoryId;
    shape: CardShape;
  }) => string;
  removeQuote: (id: string) => void;
  showToast: (message: string) => void;
};

let toastTimer: ReturnType<typeof setTimeout> | undefined;

function poolOf(state: { category: CategoryId | "all"; customQuotes: Quote[] }) {
  return quotesByCategory(state.category, state.customQuotes);
}

export const useQuotesStore = create<QuotesState>((set, get) => ({
  tab: "feed",
  category: "all",
  index: 0,
  favorites: [],
  customQuotes: [],
  toast: null,
  hydrated: false,
  setTab: (tab) => set({ tab }),
  setCategory: (category) => {
    set({ category, index: 0, tab: "feed" });
  },
  hydrate: () => {
    if (get().hydrated) return;
    const favorites = readFavorites();
    const customQuotes = readCustom();
    const pool = quotesByCategory("all", customQuotes);
    set({
      favorites,
      customQuotes,
      index: dailyStartIndex(Math.max(pool.length, 1)),
      hydrated: true,
    });
  },
  next: () => {
    const pool = poolOf(get());
    if (pool.length === 0) return;
    set({ index: (get().index + 1) % pool.length });
  },
  prev: () => {
    const pool = poolOf(get());
    if (pool.length === 0) return;
    set({ index: (get().index - 1 + pool.length) % pool.length });
  },
  goTo: (id) => {
    const pool = quotesByCategory("all", get().customQuotes);
    const index = pool.findIndex((q) => q.id === id);
    if (index < 0) return;
    set({ category: "all", tab: "feed", index });
  },
  shuffle: () => {
    const pool = poolOf(get());
    if (pool.length < 2) return;
    let next = Math.floor(Math.random() * pool.length);
    if (next === get().index) next = (next + 1) % pool.length;
    set({ index: next });
  },
  toggleFavorite: (id) => {
    const current = get().favorites;
    const favorites = current.includes(id)
      ? current.filter((x) => x !== id)
      : [...current, id];
    writeFavorites(favorites);
    set({ favorites });
  },
  saveQuote: (input) => {
    const text = input.text.trim();
    const author = input.author.trim() || "مجهول";
    const customQuotes = get().customQuotes;
    if (input.id) {
      const next = customQuotes.map((q) =>
        q.id === input.id
          ? { ...q, text, author, category: input.category, shape: input.shape, custom: true }
          : q,
      );
      writeCustom(next);
      set({ customQuotes: next });
      return input.id;
    }
    const id = `c-${Date.now()}`;
    const quote: Quote = {
      id,
      text,
      author,
      category: input.category,
      shape: input.shape,
      custom: true,
    };
    const next = [quote, ...customQuotes];
    writeCustom(next);
    set({ customQuotes: next });
    return id;
  },
  removeQuote: (id) => {
    const customQuotes = get().customQuotes.filter((q) => q.id !== id);
    const favorites = get().favorites.filter((fid) => fid !== id);
    writeCustom(customQuotes);
    writeFavorites(favorites);
    set({ customQuotes, favorites });
  },
  showToast: (message) => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: message });
    toastTimer = setTimeout(() => set({ toast: null }), 1600);
  },
}));

export function isCategoryId(value: string): value is CategoryId {
  return (CATEGORY_IDS as readonly string[]).includes(value);
}
