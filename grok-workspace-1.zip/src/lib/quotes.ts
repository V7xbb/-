export const CATEGORY_IDS = ["hikma", "hayat", "hubb", "shiir", "himma"] as const;

export type CategoryId = (typeof CATEGORY_IDS)[number];

export type CardShape = "ink" | "paper" | "verse" | "frame" | "window" | "mark";

export type Quote = {
  id: string;
  text: string;
  author: string;
  category: CategoryId;
  shape: CardShape;
  custom?: boolean;
};

export const CATEGORIES: Record<
  CategoryId,
  { label: string; hint: string }
> = {
  hikma: { label: "حكمة", hint: "أقوال تُقيم النفس" },
  hayat: { label: "حياة", hint: "عن الأيام وصروفها" },
  hubb: { label: "حب", hint: "القلب وما يسكنه" },
  shiir: { label: "شعر", hint: "أبيات خالدة" },
  himma: { label: "همة", hint: "عزمٌ لا يلين" },
};

export const QUOTES: Quote[] = [
  {
    id: "q01",
    text: "قيمةُ كلِّ امرئٍ ما يُحسِنُه.",
    author: "علي بن أبي طالب",
    category: "hikma",
    shape: "ink",
  },
  {
    id: "q02",
    text: "لا تكن عبدَ غيرِك وقد جعلك الله حرّاً.",
    author: "علي بن أبي طالب",
    category: "hikma",
    shape: "paper",
  },
  {
    id: "q03",
    text: "إذا تمّ العقلُ نقص الكلام.",
    author: "علي بن أبي طالب",
    category: "hikma",
    shape: "mark",
  },
  {
    id: "q04",
    text: "المرءُ مخبوءٌ تحت لسانه.",
    author: "علي بن أبي طالب",
    category: "hikma",
    shape: "frame",
  },
  {
    id: "q05",
    text: "عِلمٌ بلا عملٍ كشجرٍ بلا ثمر.",
    author: "الشافعي",
    category: "hikma",
    shape: "window",
  },
  {
    id: "q06",
    text: "رُبَّ أخٍ لك لم تلِدْه أمُّك.",
    author: "مثل عربي",
    category: "hikma",
    shape: "verse",
  },
  {
    id: "q07",
    text: "خيرُ الأمور أوسطُها.",
    author: "مثل عربي",
    category: "hikma",
    shape: "paper",
  },
  {
    id: "q08",
    text: "من كثر كلامُه كثر خطؤه.",
    author: "مثل عربي",
    category: "hikma",
    shape: "ink",
  },
  {
    id: "q09",
    text: "تعبٌ كلُّها الحياةُ فما أعجبُ إلا من راغبٍ في ازدياد.",
    author: "أبو العلاء المعري",
    category: "hayat",
    shape: "verse",
  },
  {
    id: "q10",
    text: "الدهرُ يومان: يومٌ لك ويومٌ عليك.",
    author: "علي بن أبي طالب",
    category: "hayat",
    shape: "frame",
  },
  {
    id: "q11",
    text: "ألا ليت الشبابَ يعودُ يوماً فأخبرَه بما فعل المشيبُ.",
    author: "أبو العتاهية",
    category: "hayat",
    shape: "paper",
  },
  {
    id: "q12",
    text: "ومن نكدِ الدنيا على الحرِّ أن يرى عدوّاً له ما من صداقتِه بُدُّ.",
    author: "المتنبي",
    category: "hayat",
    shape: "ink",
  },
  {
    id: "q13",
    text: "إذا كنت ذا رأيٍ فكن ذا عزيمةٍ فإن فسادَ الرأي أن تتردّدا.",
    author: "قطري بن الفجاءة",
    category: "hayat",
    shape: "window",
  },
  {
    id: "q14",
    text: "لكلِّ داءٍ دواءٌ يُستطبُّ به إلا الحماقةَ أعيت من يداويها.",
    author: "المتنبي",
    category: "hayat",
    shape: "mark",
  },
  {
    id: "q15",
    text: "الصبرُ صبران: صبرٌ على ما تكره وصبرٌ عمّا تحب.",
    author: "علي بن أبي طالب",
    category: "hayat",
    shape: "paper",
  },
  {
    id: "q16",
    text: "ما أضيقَ العيشَ لولا فسحةُ الأمل.",
    author: "أحمد شوقي",
    category: "hayat",
    shape: "verse",
  },
  {
    id: "q17",
    text: "أمرُّ على الديارِ ديارِ ليلى أُقبِّل ذا الجدارَ وذا الجدارا.",
    author: "قيس بن الملوح",
    category: "hubb",
    shape: "window",
  },
  {
    id: "q18",
    text: "نقل فؤادَك حيث شئت من الهوى ما الحبُّ إلا للحبيب الأوّل.",
    author: "أبو تمام",
    category: "hubb",
    shape: "paper",
  },
  {
    id: "q19",
    text: "يقولون ليلى بالعراق مريضةٌ فيا ليتني كنتُ الطبيبَ المداويا.",
    author: "قيس بن الملوح",
    category: "hubb",
    shape: "verse",
  },
  {
    id: "q20",
    text: "فوالله ما أدري وإني لصادقٌ أداءٌ عراني من حبابك أم سحر.",
    author: "جميل بثينة",
    category: "hubb",
    shape: "ink",
  },
  {
    id: "q21",
    text: "وكنتُ إذا فارقتُ ليلى كأنني أُفارق قلبي لا أُفارق دارا.",
    author: "قيس بن الملوح",
    category: "hubb",
    shape: "frame",
  },
  {
    id: "q22",
    text: "ولقد ذكرتُكِ والرماحُ نواهلٌ مني وبيضُ الهند تقطر من دمي.",
    author: "عنترة بن شداد",
    category: "hubb",
    shape: "mark",
  },
  {
    id: "q23",
    text: "إذا لم تُعش عاشقاً متَّ جاهلاً فمن لم يذقْ مرَّ الهوى لم يعش حُرا.",
    author: "أبو نواس",
    category: "hubb",
    shape: "paper",
  },
  {
    id: "q24",
    text: "علقتُ الهوى منها وليداً فلم يزل إلى اليوم يَنْمي حبُّها ويزيدُ.",
    author: "جميل بثينة",
    category: "hubb",
    shape: "ink",
  },
  {
    id: "q25",
    text: "على قدر أهل العزم تأتي العزائمُ وتأتي على قدر الكرام المكارمُ.",
    author: "المتنبي",
    category: "shiir",
    shape: "ink",
  },
  {
    id: "q26",
    text: "إذا غامرتَ في شرفٍ مرومِ فلا تقنعْ بما دون النجومِ.",
    author: "المتنبي",
    category: "shiir",
    shape: "frame",
  },
  {
    id: "q27",
    text: "ذو العقل يشقى في النعيم بعقله وأخو الجهالة في الشقاوة ينعم.",
    author: "المتنبي",
    category: "shiir",
    shape: "paper",
  },
  {
    id: "q28",
    text: "إذا رأيت نيوبَ الليث بارزةً فلا تظننَّ أن الليث يبتسم.",
    author: "المتنبي",
    category: "shiir",
    shape: "mark",
  },
  {
    id: "q29",
    text: "ولو أني حُبيتُ الخلد فرداً لما أحببتُ بالخلد انفرادا.",
    author: "أبو فراس الحمداني",
    category: "shiir",
    shape: "verse",
  },
  {
    id: "q30",
    text: "سيذكرني قومي إذا جدَّ جدُّهم وفي الليلة الظلماء يُفتقد البدرُ.",
    author: "أبو فراس الحمداني",
    category: "shiir",
    shape: "window",
  },
  {
    id: "q31",
    text: "الخيلُ والليلُ والبيداءُ تعرفني والسيفُ والرمحُ والقرطاسُ والقلمُ.",
    author: "المتنبي",
    category: "shiir",
    shape: "ink",
  },
  {
    id: "q32",
    text: "أنا الذي نظر الأعمى إلى أدبي وأسمعت كلماتي من به صممُ.",
    author: "المتنبي",
    category: "shiir",
    shape: "paper",
  },
  {
    id: "q33",
    text: "بقدر الكدِّ تُكتسب المعالي ومن طلب العلا سهر الليالي.",
    author: "الشافعي",
    category: "himma",
    shape: "frame",
  },
  {
    id: "q34",
    text: "ومن طلب العلا من غير كدٍّ أضاع العمر في طلب المحال.",
    author: "الشافعي",
    category: "himma",
    shape: "paper",
  },
  {
    id: "q35",
    text: "على المرء أن يسعى إلى الخير جهده وليس عليه أن تتمَّ المقاصدُ.",
    author: "مثل عربي",
    category: "himma",
    shape: "verse",
  },
  {
    id: "q36",
    text: "نفسُ عصامٍ سوّدتْ عصاما وعلّمتْه الكرَّ والإقداما.",
    author: "مثل عربي",
    category: "himma",
    shape: "mark",
  },
  {
    id: "q37",
    text: "همّتك على قدر عزيمتك، والعزيمة على قدر الصبر.",
    author: "حكمة عربية",
    category: "himma",
    shape: "window",
  },
  {
    id: "q38",
    text: "من جدَّ وجد، ومن زرع حصد، ومن سار على الدرب وصل.",
    author: "مثل عربي",
    category: "himma",
    shape: "ink",
  },
  {
    id: "q39",
    text: "لا يُدرك المجدَ إلا سيّدٌ فَطِنٌ لما يشقُّ على الساداتِ فعّالُ.",
    author: "المتنبي",
    category: "himma",
    shape: "paper",
  },
  {
    id: "q40",
    text: "عش عزيزاً أو مُت وأنت كريمٌ بين طعن القنا وخفق البنود.",
    author: "المتنبي",
    category: "himma",
    shape: "frame",
  },
];

export const CARD_SHAPES: { id: CardShape; label: string }[] = [
  { id: "ink", label: "حبر" },
  { id: "paper", label: "ورقة" },
  { id: "verse", label: "عمود" },
  { id: "frame", label: "إطار" },
  { id: "window", label: "قوس" },
  { id: "mark", label: "وسم" },
];

const SHAPE_IDS: CardShape[] = CARD_SHAPES.map((s) => s.id);

function hashId(id: string): number {
  let n = 0;
  for (let i = 0; i < id.length; i += 1) n = (n * 31 + id.charCodeAt(i)) >>> 0;
  return n;
}

export function quotesByCategory(
  category: CategoryId | "all",
  extra: Quote[] = [],
): Quote[] {
  const all = extra.length === 0 ? QUOTES : [...extra, ...QUOTES];
  if (category === "all") return all;
  return all.filter((q) => q.category === category);
}

export function quoteById(id: string, extra: Quote[] = []): Quote | undefined {
  return extra.find((q) => q.id === id) ?? QUOTES.find((q) => q.id === id);
}

export function dailyStartIndex(length: number): number {
  const day = Math.floor(Date.now() / 86_400_000);
  return ((day % length) + length) % length;
}

export function shapeFor(quote: Quote): CardShape {
  return quote.shape ?? SHAPE_IDS[hashId(quote.id) % SHAPE_IDS.length];
}

export function isCardShape(value: string): value is CardShape {
  return (SHAPE_IDS as string[]).includes(value);
}
