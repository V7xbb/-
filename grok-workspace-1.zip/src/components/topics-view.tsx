import { CATEGORIES, CATEGORY_IDS, quotesByCategory } from "@/lib/quotes";
import { useQuotesStore } from "@/lib/store";
import { Spark } from "@/components/spark";
import { cn } from "@/lib/utils";

export function TopicsView() {
  const category = useQuotesStore((s) => s.category);
  const customQuotes = useQuotesStore((s) => s.customQuotes);
  const setCategory = useQuotesStore((s) => s.setCategory);
  const allCount = quotesByCategory("all", customQuotes).length;

  return (
    <section className="flex min-h-0 flex-1 flex-col px-5">
      <header className="pb-4 pt-1">
        <p className="text-xs font-medium text-fg-muted">اختر مزاج البطاقة</p>
        <h2 className="mt-1 font-display text-2xl text-fg">التصنيفات</h2>
      </header>

      <div className="stagger-in grid min-h-0 flex-1 grid-cols-1 gap-3 overflow-y-auto pb-2">
        <button
          type="button"
          onClick={() => setCategory("all")}
          className={cn(
            "flex items-center justify-between rounded-xl border px-5 py-5 text-start transition-colors duration-150",
            category === "all"
              ? "border-accent bg-paper text-paper-fg"
              : "border-border bg-bg-elevated text-fg hover:bg-bg-subtle",
          )}
        >
          <span>
            <span className="flex items-center gap-2 text-sm font-medium">
              <Spark
                className={cn(
                  "size-2",
                  category === "all" ? "bg-paper-fg" : "bg-accent",
                )}
              />
              الكل
            </span>
            <span
              className={cn(
                "mt-1 block text-xs",
                category === "all" ? "text-paper-muted" : "text-fg-muted",
              )}
            >
              كل الأشكال في موجة واحدة
            </span>
          </span>
          <span className="tabular-nums text-sm">{allCount}</span>
        </button>

        {CATEGORY_IDS.map((id) => {
          const meta = CATEGORIES[id];
          const count = quotesByCategory(id, customQuotes).length;
          const active = category === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setCategory(id)}
              className={cn(
                "flex items-center justify-between rounded-xl border px-5 py-5 text-start transition-colors duration-150",
                active
                  ? "border-accent bg-paper text-paper-fg"
                  : "border-border bg-bg-elevated text-fg hover:bg-bg-subtle",
              )}
            >
              <span>
                <span className="flex items-center gap-2 text-sm font-medium">
                  <Spark
                    className={cn("size-2", active ? "bg-paper-fg" : "bg-accent")}
                  />
                  {meta.label}
                </span>
                <span
                  className={cn(
                    "mt-1 block text-xs",
                    active ? "text-paper-muted" : "text-fg-muted",
                  )}
                >
                  {meta.hint}
                </span>
              </span>
              <span className="tabular-nums text-sm">{count}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
