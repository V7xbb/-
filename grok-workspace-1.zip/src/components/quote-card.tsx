import { CATEGORIES, type Quote, shapeFor } from "@/lib/quotes";
import { cn } from "@/lib/utils";
import { CornerFrame, Spark, StarMark } from "@/components/spark";

const PAPER_SHAPES = new Set(["paper", "window"]);

export function QuoteCard({
  quote,
  className,
  compact = false,
}: {
  quote: Quote;
  className?: string;
  compact?: boolean;
}) {
  const shape = shapeFor(quote);
  const onPaper = PAPER_SHAPES.has(shape);
  const category = CATEGORIES[quote.category];
  const long = quote.text.length > 72;

  return (
    <article
      className={cn(
        "quote-shape",
        `quote-shape-${shape}`,
        compact && "is-compact",
        className,
      )}
      aria-label={`اقتباس لـ ${quote.author}`}
    >
      {shape === "frame" ? <CornerFrame /> : null}
      {shape === "mark" ? (
        <StarMark className={cn("size-5", compact ? "mb-3" : "mb-6")} tone="accent" />
      ) : null}
      {shape === "window" ? (
        <Spark className={cn(compact ? "mb-3" : "mb-6")} />
      ) : null}
      {shape === "paper" ? (
        <span
          className={cn(
            "flex items-center gap-2 text-xs font-medium tracking-wide text-paper-muted",
            compact ? "mb-3" : "mb-6",
          )}
        >
          <Spark className="size-1.5 bg-paper-muted" />
          {category.label}
        </span>
      ) : null}
      {shape !== "paper" && shape !== "window" ? (
        <p
          className={cn(
            "text-xs font-medium tracking-wide",
            compact ? "mb-3" : "mb-6",
            onPaper ? "text-paper-muted" : "text-fg-muted",
          )}
        >
          {category.label}
        </p>
      ) : null}

      <p
        className={cn(
          "font-display leading-snug text-balance",
          compact
            ? "text-lg"
            : long
              ? "text-xl"
              : shape === "ink"
                ? "text-3xl"
                : "text-2xl",
          onPaper ? "text-paper-fg" : "text-fg",
        )}
      >
        {quote.text}
      </p>

      <div
        className={cn(
          "flex flex-col items-center gap-2",
          compact ? "mt-4" : "mt-8",
          onPaper ? "text-paper-muted" : "text-fg-muted",
        )}
      >
        <span
          className={cn(
            "block h-px w-8",
            onPaper ? "bg-paper-muted/50" : "bg-border-strong",
          )}
        />
        <p className="font-sans text-sm font-medium">{quote.author}</p>
      </div>
    </article>
  );
}
