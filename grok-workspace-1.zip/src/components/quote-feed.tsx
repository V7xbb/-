import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronUp, Heart, Share2, Shuffle } from "lucide-react";
import { QuoteCard } from "@/components/quote-card";
import { Button } from "@/components/ui/button";
import { CATEGORIES, quotesByCategory } from "@/lib/quotes";
import { useQuotesStore } from "@/lib/store";
import { cn } from "@/lib/utils";

async function shareQuote(
  text: string,
  author: string,
  onCopied: () => void,
) {
  const payload = `«${text}»\n— ${author}\n\nقَبَس`;
  if (typeof navigator !== "undefined" && navigator.share) {
    try {
      await navigator.share({ title: "قَبَس", text: payload });
      return;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
    }
  }
  try {
    await navigator.clipboard.writeText(payload);
    onCopied();
  } catch {
    onCopied();
  }
}

export function QuoteFeed() {
  const index = useQuotesStore((s) => s.index);
  const favorites = useQuotesStore((s) => s.favorites);
  const customQuotes = useQuotesStore((s) => s.customQuotes);
  const category = useQuotesStore((s) => s.category);
  const next = useQuotesStore((s) => s.next);
  const prev = useQuotesStore((s) => s.prev);
  const shuffle = useQuotesStore((s) => s.shuffle);
  const toggleFavorite = useQuotesStore((s) => s.toggleFavorite);
  const showToast = useQuotesStore((s) => s.showToast);
  const feed = quotesByCategory(category, customQuotes);
  const current = feed.length === 0 ? null : feed[((index % feed.length) + feed.length) % feed.length];

  const [dir, setDir] = useState<"up" | "down">("up");
  const [animKey, setAnimKey] = useState(0);
  const startY = useRef<number | null>(null);
  const startX = useRef<number | null>(null);

  useEffect(() => {
    setAnimKey((k) => k + 1);
  }, [index]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "ArrowUp" || event.key === "ArrowRight") {
        event.preventDefault();
        setDir("up");
        next();
      }
      if (event.key === "ArrowDown" || event.key === "ArrowLeft") {
        event.preventDefault();
        setDir("down");
        prev();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev]);

  if (!current) return null;

  const liked = favorites.includes(current.id);
  const pos = `${index + 1} / ${feed.length}`;
  const label =
    category === "all" ? "كل الاقتباسات" : CATEGORIES[category].label;

  function onPointerDown(event: React.PointerEvent<HTMLDivElement>) {
    startY.current = event.clientY;
    startX.current = event.clientX;
  }

  function onPointerUp(event: React.PointerEvent<HTMLDivElement>) {
    if (startY.current == null || startX.current == null) return;
    const dy = event.clientY - startY.current;
    const dx = event.clientX - startX.current;
    startY.current = null;
    startX.current = null;
    if (Math.abs(dy) < 48 || Math.abs(dy) < Math.abs(dx)) return;
    if (dy < 0) {
      setDir("up");
      next();
    } else {
      setDir("down");
      prev();
    }
  }

  return (
    <section className="flex min-h-0 flex-1 flex-col px-5">
      <header className="flex items-center justify-between pt-1 pb-3">
        <p className="text-xs font-medium text-fg-muted">{label}</p>
        <p className="text-xs tabular-nums text-fg-subtle">{pos}</p>
      </header>

      <div
        className="relative flex min-h-0 flex-1 touch-none items-center justify-center overflow-hidden"
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
        onPointerCancel={() => {
          startY.current = null;
          startX.current = null;
        }}
      >
        <div
          key={animKey}
          className={cn(
            "flex w-full items-center justify-center",
            dir === "up" ? "feed-enter-up" : "feed-enter-down",
          )}
        >
          <QuoteCard quote={current} />
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 pb-3 pt-2">
        <Button
          variant="icon"
          size="icon"
          aria-label="الاقتباس السابق"
          onClick={() => {
            setDir("down");
            prev();
          }}
        >
          <ChevronDown className="size-5" />
        </Button>

        <div className="flex items-center gap-2">
          <Button
            variant="icon"
            size="icon"
            aria-label="اقتباس عشوائي"
            onClick={() => {
              setDir("up");
              shuffle();
            }}
          >
            <Shuffle className="size-5" />
          </Button>
          <Button
            variant="icon"
            size="icon"
            aria-label={liked ? "إزالة من المفضلة" : "حفظ في المفضلة"}
            onClick={() => toggleFavorite(current.id)}
          >
            <Heart
              className={cn("size-5", liked && "fill-mark text-mark")}
            />
          </Button>
          <Button
            variant="icon"
            size="icon"
            aria-label="مشاركة الاقتباس"
            onClick={() =>
              void shareQuote(current.text, current.author, () =>
                showToast("تم نسخ الاقتباس"),
              )
            }
          >
            <Share2 className="size-5" />
          </Button>
        </div>

        <Button
          variant="icon"
          size="icon"
          aria-label="الاقتباس التالي"
          onClick={() => {
            setDir("up");
            next();
          }}
        >
          <ChevronUp className="size-5" />
        </Button>
      </div>
    </section>
  );
}
