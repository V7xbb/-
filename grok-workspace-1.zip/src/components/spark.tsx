import { cn } from "@/lib/utils";

export function Spark({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn("spark", className)}
    />
  );
}

export function StarMark({
  className,
  tone = "accent",
}: {
  className?: string;
  tone?: "accent" | "paper" | "ink";
}) {
  const fill =
    tone === "paper"
      ? "var(--color-paper-fg)"
      : tone === "ink"
        ? "var(--color-fg)"
        : "var(--color-accent)";
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn("size-4", className)}
      aria-hidden="true"
    >
      <path
        fill={fill}
        d="M12 1.8 13.1 9 20.4 6.2 15.2 12 20.4 17.8 13.1 15 12 22.2 10.9 15 3.6 17.8 8.8 12 3.6 6.2 10.9 9Z"
      />
    </svg>
  );
}

export function CornerFrame({ tone = "light" }: { tone?: "light" | "dark" }) {
  const color =
    tone === "dark"
      ? "var(--color-paper-muted)"
      : "var(--color-fg-muted)";
  return (
    <span aria-hidden="true" className="pointer-events-none absolute inset-3">
      <i
        className="absolute start-0 top-0 size-3 border-s border-t"
        style={{ borderColor: color }}
      />
      <i
        className="absolute end-0 top-0 size-3 border-e border-t"
        style={{ borderColor: color }}
      />
      <i
        className="absolute start-0 bottom-0 size-3 border-s border-b"
        style={{ borderColor: color }}
      />
      <i
        className="absolute end-0 bottom-0 size-3 border-e border-b"
        style={{ borderColor: color }}
      />
    </span>
  );
}
