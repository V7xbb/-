import { Heart } from "lucide-react";
import { CATEGORIES, quoteById } from "@/lib/quotes";
import { useQuotesStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Spark } from "@/components/spark";

export function FavoritesView() {
  const favorites = useQuotesStore((s) => s.favorites);
  const customQuotes = useQuotesStore((s) => s.customQuotes);
  const setTab = useQuotesStore((s) => s.setTab);
  const goTo = useQuotesStore((s) => s.goTo);
  const quotes = favorites
    .map((id) => quoteById(id, customQuotes))
    .filter((q): q is NonNullable<typeof q> => Boolean(q));

  if (quotes.length === 0) {
    return (
      <section className="flex min-h-0 flex-1 flex-col items-center justify-center px-8 text-center">
        <span className="mb-5 flex size-14 items-center justify-center rounded-full border border-border bg-bg-elevated">
          <Heart className="size-5 text-fg-muted" />
        </span>
        <h2 className="font-display text-2xl text-fg">لا محفوظات بعد</h2>
        <p className="mt-2 max-w-xs text-sm leading-normal text-fg-muted">
          احفظ ما يلامسك من البطاقات، وتعود إليه هنا في أي وقت.
        </p>
        <Button className="mt-6" onClick={() => setTab("feed")}>
          تصفّح الاقتباسات
        </Button>
      </section>
    );
  }

  return (
    <section className="flex min-h-0 flex-1 flex-col px-5">
      <header className="pb-4 pt-1">
        <p className="text-xs font-medium text-fg-muted">محفوظاتك</p>
        <h2 className="mt-1 font-display text-2xl text-fg">المفضلة</h2>
      </header>
      <ul className="min-h-0 flex-1 space-y-3 overflow-y-auto pb-2">
        {quotes.map((quote) => (
          <li key={quote.id}>
            <button
              type="button"
              onClick={() => goTo(quote.id)}
              className="w-full rounded-xl border border-border bg-bg-elevated px-4 py-4 text-start transition-colors duration-150 hover:bg-bg-subtle"
            >
              <span className="flex items-center gap-2 text-xs font-medium text-fg-muted">
                <Spark className="size-1.5" />
                {CATEGORIES[quote.category].label}
              </span>
              <p className="mt-2 font-display text-lg leading-snug text-fg">
                {quote.text}
              </p>
              <p className="mt-3 text-xs text-fg-subtle">{quote.author}</p>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
