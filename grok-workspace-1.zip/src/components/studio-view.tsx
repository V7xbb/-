import { useState } from "react";
import { PenLine, Trash2 } from "lucide-react";
import { QuoteCard } from "@/components/quote-card";
import { Button } from "@/components/ui/button";
import { Spark } from "@/components/spark";
import {
  CARD_SHAPES,
  CATEGORIES,
  CATEGORY_IDS,
  type CardShape,
  type CategoryId,
  type Quote,
} from "@/lib/quotes";
import { useQuotesStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function StudioView() {
  const customQuotes = useQuotesStore((s) => s.customQuotes);
  const saveQuote = useQuotesStore((s) => s.saveQuote);
  const removeQuote = useQuotesStore((s) => s.removeQuote);
  const goTo = useQuotesStore((s) => s.goTo);
  const showToast = useQuotesStore((s) => s.showToast);

  const [text, setText] = useState("");
  const [author, setAuthor] = useState("");
  const [category, setCategory] = useState<CategoryId>("hikma");
  const [shape, setShape] = useState<CardShape>("paper");
  const [editingId, setEditingId] = useState<string | null>(null);

  const preview: Quote = {
    id: "preview",
    text: text.trim() || "اكتب اقتباسك هنا",
    author: author.trim() || "قائل مجهول",
    category,
    shape,
  };

  function resetForm() {
    setText("");
    setAuthor("");
    setCategory("hikma");
    setShape("paper");
    setEditingId(null);
  }

  function onSave() {
    const trimmed = text.trim();
    if (!trimmed) {
      showToast("اكتب الاقتباس أولاً");
      return;
    }
    const id = saveQuote({
      id: editingId ?? undefined,
      text: trimmed,
      author,
      category,
      shape,
    });
    showToast(editingId ? "تم تحديث البطاقة" : "أُضيفت البطاقة");
    resetForm();
    goTo(id);
  }

  function loadQuote(quote: Quote) {
    setEditingId(quote.id);
    setText(quote.text);
    setAuthor(quote.author);
    setCategory(quote.category);
    setShape(quote.shape);
  }

  return (
    <section className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-3">
        <header className="pb-4 pt-1">
          <p className="text-xs font-medium text-fg-muted">صمّم الشكل واكتب سطرَك</p>
          <h2 className="mt-1 font-display text-2xl text-fg">أنشئ بطاقة</h2>
        </header>

        <p className="mb-2 text-xs font-medium text-fg-muted">الشكل</p>
        <div className="mb-5 grid grid-cols-3 gap-2">
          {CARD_SHAPES.map((item) => {
            const active = item.id === shape;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={active}
                onClick={() => setShape(item.id)}
                className={cn("shape-thumb", active && "is-active")}
              >
                <span className={cn("shape-thumb-body", `shape-thumb-${item.id}`)} />
                {item.label}
              </button>
            );
          })}
        </div>

        <div className="studio-preview mb-5">
          <QuoteCard quote={preview} compact />
        </div>

        <label className="mb-2 block text-xs font-medium text-fg-muted" htmlFor="quote-text">
          الاقتباس
        </label>
        <textarea
          id="quote-text"
          className="studio-field studio-field-quote mb-4"
          maxLength={220}
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder="اكتب بيتاً أو حكمة…"
        />

        <label className="mb-2 block text-xs font-medium text-fg-muted" htmlFor="quote-author">
          القائل
        </label>
        <input
          id="quote-author"
          className="studio-field mb-4"
          maxLength={60}
          value={author}
          onChange={(event) => setAuthor(event.target.value)}
          placeholder="اسمك، أو المتنبي، أو مجهول"
        />

        <p className="mb-2 text-xs font-medium text-fg-muted">التصنيف</p>
        <div className="mb-5 flex flex-wrap gap-2">
          {CATEGORY_IDS.map((id) => {
            const active = id === category;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setCategory(id)}
                className={cn(
                  "h-11 rounded-full border px-4 text-sm font-medium transition-colors duration-150",
                  active
                    ? "border-accent bg-paper text-paper-fg"
                    : "border-border bg-bg-elevated text-fg-muted",
                )}
              >
                {CATEGORIES[id].label}
              </button>
            );
          })}
        </div>

        <Button className="w-full" size="lg" onClick={onSave}>
          <PenLine className="size-4" />
          {editingId ? "تحديث البطاقة" : "حفظ البطاقة"}
        </Button>
        {editingId ? (
          <Button
            className="mt-2 w-full"
            variant="ghost"
            onClick={resetForm}
          >
            إلغاء التعديل
          </Button>
        ) : null}

        {customQuotes.length > 0 ? (
          <div className="mt-8">
            <p className="mb-3 text-xs font-medium text-fg-muted">بطاقاتك</p>
            <ul className="space-y-2">
              {customQuotes.map((quote) => (
                <li key={quote.id}>
                  <div className="flex items-stretch gap-2">
                    <button
                      type="button"
                      onClick={() => loadQuote(quote)}
                      className="min-w-0 flex-1 rounded-xl border border-border bg-bg-elevated px-4 py-3 text-start"
                    >
                      <span className="flex items-center gap-2 text-xs text-fg-muted">
                        <Spark className="size-1.5" />
                        {CATEGORIES[quote.category].label}
                      </span>
                      <p className="mt-1 truncate font-display text-base text-fg">
                        {quote.text}
                      </p>
                    </button>
                    <button
                      type="button"
                      aria-label="حذف البطاقة"
                      onClick={() => {
                        if (editingId === quote.id) resetForm();
                        removeQuote(quote.id);
                        showToast("حُذفت البطاقة");
                      }}
                      className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-border bg-bg-elevated text-fg-muted"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </section>
  );
}
