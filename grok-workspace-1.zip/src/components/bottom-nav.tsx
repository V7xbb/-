import { BookOpen, Heart, LayoutGrid, PenLine } from "lucide-react";
import type { TabId } from "@/lib/store";
import { useQuotesStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const TABS: { id: TabId; label: string; icon: typeof BookOpen }[] = [
  { id: "feed", label: "اقتباسات", icon: BookOpen },
  { id: "studio", label: "أنشئ", icon: PenLine },
  { id: "favorites", label: "المفضلة", icon: Heart },
  { id: "topics", label: "تصنيف", icon: LayoutGrid },
];

export function BottomNav() {
  const tab = useQuotesStore((s) => s.tab);
  const setTab = useQuotesStore((s) => s.setTab);
  const activeIndex = TABS.findIndex((t) => t.id === tab);

  return (
    <nav
      aria-label="التنقل"
      className="relative mx-4 mb-4 mt-1 grid grid-cols-4 rounded-full border border-border bg-bg-elevated p-1.5"
    >
      <span
        className="nav-pill"
        style={{ insetInlineStart: `calc(${activeIndex * 25}% + 6px)` }}
      />
      {TABS.map((item) => {
        const Icon = item.icon;
        const active = item.id === tab;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            aria-current={active ? "page" : undefined}
            className={cn(
              "relative z-10 flex h-11 flex-col items-center justify-center gap-0.5 rounded-full text-xs font-medium transition-colors duration-150",
              active ? "text-fg" : "text-fg-muted",
            )}
          >
            <Icon
              className={cn("size-4", active && item.id === "favorites" && "fill-mark text-mark")}
            />
            {item.label}
          </button>
        );
      })}
    </nav>
  );
}
