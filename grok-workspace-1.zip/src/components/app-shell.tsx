import { useEffect } from "react";
import { BottomNav } from "@/components/bottom-nav";
import { FavoritesView } from "@/components/favorites-view";
import { QuoteFeed } from "@/components/quote-feed";
import { Spark } from "@/components/spark";
import { StudioView } from "@/components/studio-view";
import { TopicsView } from "@/components/topics-view";
import { useQuotesStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function AppShell() {
  const hydrate = useQuotesStore((s) => s.hydrate);
  const hydrated = useQuotesStore((s) => s.hydrated);
  const tab = useQuotesStore((s) => s.tab);
  const toast = useQuotesStore((s) => s.toast);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="phone-stage">
      <div className="phone-shell">
        <header className="phone-header flex items-center justify-center gap-2 px-5 pb-2">
          <Spark className="size-2" />
          <h1 className="font-display text-2xl leading-tight tracking-wide text-fg">
            قَبَس
          </h1>
        </header>

        {!hydrated ? (
          <div className="flex min-h-0 flex-1 items-center justify-center">
            <Spark className="size-3" />
          </div>
        ) : (
          <>
            {tab === "feed" ? <QuoteFeed /> : null}
            {tab === "studio" ? <StudioView /> : null}
            {tab === "favorites" ? <FavoritesView /> : null}
            {tab === "topics" ? <TopicsView /> : null}
          </>
        )}

        <div
          className={cn("toast-copy", toast && "is-on")}
          role="status"
          aria-live="polite"
          aria-hidden={toast ? undefined : true}
        >
          {toast}
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
