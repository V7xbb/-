import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Heart, c as BookOpen, i as LayoutGrid, n as Shuffle, o as ChevronUp, r as Share2, s as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-eUgaJQ8m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORY_IDS = [
	"hikma",
	"hayat",
	"hubb",
	"shiir",
	"himma"
];
var CATEGORIES = {
	hikma: {
		label: "حكمة",
		hint: "أقوال تُقيم النفس"
	},
	hayat: {
		label: "حياة",
		hint: "عن الأيام وصروفها"
	},
	hubb: {
		label: "حب",
		hint: "القلب وما يسكنه"
	},
	shiir: {
		label: "شعر",
		hint: "أبيات خالدة"
	},
	himma: {
		label: "همة",
		hint: "عزمٌ لا يلين"
	}
};
var QUOTES = [
	{
		id: "q01",
		text: "قيمةُ كلِّ امرئٍ ما يُحسِنُه.",
		author: "علي بن أبي طالب",
		category: "hikma",
		shape: "ink"
	},
	{
		id: "q02",
		text: "لا تكن عبدَ غيرِك وقد جعلك الله حرّاً.",
		author: "علي بن أبي طالب",
		category: "hikma",
		shape: "paper"
	},
	{
		id: "q03",
		text: "إذا تمّ العقلُ نقص الكلام.",
		author: "علي بن أبي طالب",
		category: "hikma",
		shape: "mark"
	},
	{
		id: "q04",
		text: "المرءُ مخبوءٌ تحت لسانه.",
		author: "علي بن أبي طالب",
		category: "hikma",
		shape: "frame"
	},
	{
		id: "q05",
		text: "عِلمٌ بلا عملٍ كشجرٍ بلا ثمر.",
		author: "الشافعي",
		category: "hikma",
		shape: "window"
	},
	{
		id: "q06",
		text: "رُبَّ أخٍ لك لم تلِدْه أمُّك.",
		author: "مثل عربي",
		category: "hikma",
		shape: "verse"
	},
	{
		id: "q07",
		text: "خيرُ الأمور أوسطُها.",
		author: "مثل عربي",
		category: "hikma",
		shape: "paper"
	},
	{
		id: "q08",
		text: "من كثر كلامُه كثر خطؤه.",
		author: "مثل عربي",
		category: "hikma",
		shape: "ink"
	},
	{
		id: "q09",
		text: "تعبٌ كلُّها الحياةُ فما أعجبُ إلا من راغبٍ في ازدياد.",
		author: "أبو العلاء المعري",
		category: "hayat",
		shape: "verse"
	},
	{
		id: "q10",
		text: "الدهرُ يومان: يومٌ لك ويومٌ عليك.",
		author: "علي بن أبي طالب",
		category: "hayat",
		shape: "frame"
	},
	{
		id: "q11",
		text: "ألا ليت الشبابَ يعودُ يوماً فأخبرَه بما فعل المشيبُ.",
		author: "أبو العتاهية",
		category: "hayat",
		shape: "paper"
	},
	{
		id: "q12",
		text: "ومن نكدِ الدنيا على الحرِّ أن يرى عدوّاً له ما من صداقتِه بُدُّ.",
		author: "المتنبي",
		category: "hayat",
		shape: "ink"
	},
	{
		id: "q13",
		text: "إذا كنت ذا رأيٍ فكن ذا عزيمةٍ فإن فسادَ الرأي أن تتردّدا.",
		author: "قطري بن الفجاءة",
		category: "hayat",
		shape: "window"
	},
	{
		id: "q14",
		text: "لكلِّ داءٍ دواءٌ يُستطبُّ به إلا الحماقةَ أعيت من يداويها.",
		author: "المتنبي",
		category: "hayat",
		shape: "mark"
	},
	{
		id: "q15",
		text: "الصبرُ صبران: صبرٌ على ما تكره وصبرٌ عمّا تحب.",
		author: "علي بن أبي طالب",
		category: "hayat",
		shape: "paper"
	},
	{
		id: "q16",
		text: "ما أضيقَ العيشَ لولا فسحةُ الأمل.",
		author: "أحمد شوقي",
		category: "hayat",
		shape: "verse"
	},
	{
		id: "q17",
		text: "أمرُّ على الديارِ ديارِ ليلى أُقبِّل ذا الجدارَ وذا الجدارا.",
		author: "قيس بن الملوح",
		category: "hubb",
		shape: "window"
	},
	{
		id: "q18",
		text: "نقل فؤادَك حيث شئت من الهوى ما الحبُّ إلا للحبيب الأوّل.",
		author: "أبو تمام",
		category: "hubb",
		shape: "paper"
	},
	{
		id: "q19",
		text: "يقولون ليلى بالعراق مريضةٌ فيا ليتني كنتُ الطبيبَ المداويا.",
		author: "قيس بن الملوح",
		category: "hubb",
		shape: "verse"
	},
	{
		id: "q20",
		text: "فوالله ما أدري وإني لصادقٌ أداءٌ عراني من حبابك أم سحر.",
		author: "جميل بثينة",
		category: "hubb",
		shape: "ink"
	},
	{
		id: "q21",
		text: "وكنتُ إذا فارقتُ ليلى كأنني أُفارق قلبي لا أُفارق دارا.",
		author: "قيس بن الملوح",
		category: "hubb",
		shape: "frame"
	},
	{
		id: "q22",
		text: "ولقد ذكرتُكِ والرماحُ نواهلٌ مني وبيضُ الهند تقطر من دمي.",
		author: "عنترة بن شداد",
		category: "hubb",
		shape: "mark"
	},
	{
		id: "q23",
		text: "إذا لم تُعش عاشقاً متَّ جاهلاً فمن لم يذقْ مرَّ الهوى لم يعش حُرا.",
		author: "أبو نواس",
		category: "hubb",
		shape: "paper"
	},
	{
		id: "q24",
		text: "علقتُ الهوى منها وليداً فلم يزل إلى اليوم يَنْمي حبُّها ويزيدُ.",
		author: "جميل بثينة",
		category: "hubb",
		shape: "ink"
	},
	{
		id: "q25",
		text: "على قدر أهل العزم تأتي العزائمُ وتأتي على قدر الكرام المكارمُ.",
		author: "المتنبي",
		category: "shiir",
		shape: "ink"
	},
	{
		id: "q26",
		text: "إذا غامرتَ في شرفٍ مرومِ فلا تقنعْ بما دون النجومِ.",
		author: "المتنبي",
		category: "shiir",
		shape: "frame"
	},
	{
		id: "q27",
		text: "ذو العقل يشقى في النعيم بعقله وأخو الجهالة في الشقاوة ينعم.",
		author: "المتنبي",
		category: "shiir",
		shape: "paper"
	},
	{
		id: "q28",
		text: "إذا رأيت نيوبَ الليث بارزةً فلا تظننَّ أن الليث يبتسم.",
		author: "المتنبي",
		category: "shiir",
		shape: "mark"
	},
	{
		id: "q29",
		text: "ولو أني حُبيتُ الخلد فرداً لما أحببتُ بالخلد انفرادا.",
		author: "أبو فراس الحمداني",
		category: "shiir",
		shape: "verse"
	},
	{
		id: "q30",
		text: "سيذكرني قومي إذا جدَّ جدُّهم وفي الليلة الظلماء يُفتقد البدرُ.",
		author: "أبو فراس الحمداني",
		category: "shiir",
		shape: "window"
	},
	{
		id: "q31",
		text: "الخيلُ والليلُ والبيداءُ تعرفني والسيفُ والرمحُ والقرطاسُ والقلمُ.",
		author: "المتنبي",
		category: "shiir",
		shape: "ink"
	},
	{
		id: "q32",
		text: "أنا الذي نظر الأعمى إلى أدبي وأسمعت كلماتي من به صممُ.",
		author: "المتنبي",
		category: "shiir",
		shape: "paper"
	},
	{
		id: "q33",
		text: "بقدر الكدِّ تُكتسب المعالي ومن طلب العلا سهر الليالي.",
		author: "الشافعي",
		category: "himma",
		shape: "frame"
	},
	{
		id: "q34",
		text: "ومن طلب العلا من غير كدٍّ أضاع العمر في طلب المحال.",
		author: "الشافعي",
		category: "himma",
		shape: "paper"
	},
	{
		id: "q35",
		text: "على المرء أن يسعى إلى الخير جهده وليس عليه أن تتمَّ المقاصدُ.",
		author: "مثل عربي",
		category: "himma",
		shape: "verse"
	},
	{
		id: "q36",
		text: "نفسُ عصامٍ سوّدتْ عصاما وعلّمتْه الكرَّ والإقداما.",
		author: "مثل عربي",
		category: "himma",
		shape: "mark"
	},
	{
		id: "q37",
		text: "همّتك على قدر عزيمتك، والعزيمة على قدر الصبر.",
		author: "حكمة عربية",
		category: "himma",
		shape: "window"
	},
	{
		id: "q38",
		text: "من جدَّ وجد، ومن زرع حصد، ومن سار على الدرب وصل.",
		author: "مثل عربي",
		category: "himma",
		shape: "ink"
	},
	{
		id: "q39",
		text: "لا يُدرك المجدَ إلا سيّدٌ فَطِنٌ لما يشقُّ على الساداتِ فعّالُ.",
		author: "المتنبي",
		category: "himma",
		shape: "paper"
	},
	{
		id: "q40",
		text: "عش عزيزاً أو مُت وأنت كريمٌ بين طعن القنا وخفق البنود.",
		author: "المتنبي",
		category: "himma",
		shape: "frame"
	}
];
var SHAPES = [
	"ink",
	"paper",
	"verse",
	"frame",
	"window",
	"mark"
];
function hashId(id) {
	let n = 0;
	for (let i = 0; i < id.length; i += 1) n = n * 31 + id.charCodeAt(i) >>> 0;
	return n;
}
function quotesByCategory(category) {
	if (category === "all") return QUOTES;
	return QUOTES.filter((q) => q.category === category);
}
function quoteById(id) {
	return QUOTES.find((q) => q.id === id);
}
function dailyStartIndex(length) {
	return (Math.floor(Date.now() / 864e5) % length + length) % length;
}
function shapeFor(quote) {
	return quote.shape ?? SHAPES[hashId(quote.id) % SHAPES.length];
}
var FAV_KEY = "qabas-favorites";
function readFavorites() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(FAV_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((id) => typeof id === "string");
	} catch {
		return [];
	}
}
function writeFavorites(ids) {
	window.localStorage.setItem(FAV_KEY, JSON.stringify(ids));
}
var toastTimer;
var useQuotesStore = create((set, get) => ({
	tab: "feed",
	category: "all",
	index: 0,
	favorites: [],
	toast: null,
	hydrated: false,
	setTab: (tab) => set({ tab }),
	setCategory: (category) => {
		set({
			category,
			index: 0,
			tab: "feed"
		});
	},
	hydrate: () => {
		if (get().hydrated) return;
		set({
			favorites: readFavorites(),
			index: dailyStartIndex(quotesByCategory("all").length),
			hydrated: true
		});
	},
	feed: () => quotesByCategory(get().category),
	current: () => {
		const pool = get().feed();
		if (pool.length === 0) return null;
		return pool[(get().index % pool.length + pool.length) % pool.length] ?? null;
	},
	next: () => {
		const pool = get().feed();
		if (pool.length === 0) return;
		set({ index: (get().index + 1) % pool.length });
	},
	prev: () => {
		const pool = get().feed();
		if (pool.length === 0) return;
		set({ index: (get().index - 1 + pool.length) % pool.length });
	},
	goTo: (id) => {
		const index = QUOTES.findIndex((q) => q.id === id);
		if (index < 0) return;
		set({
			category: "all",
			tab: "feed",
			index
		});
	},
	shuffle: () => {
		const pool = get().feed();
		if (pool.length < 2) return;
		let next = Math.floor(Math.random() * pool.length);
		if (next === get().index) next = (next + 1) % pool.length;
		set({ index: next });
	},
	toggleFavorite: (id) => {
		const current = get().favorites;
		const favorites = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
		writeFavorites(favorites);
		set({ favorites });
	},
	showToast: (message) => {
		if (toastTimer) clearTimeout(toastTimer);
		set({ toast: message });
		toastTimer = setTimeout(() => set({ toast: null }), 1600);
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var TABS = [
	{
		id: "feed",
		label: "اقتباسات",
		icon: BookOpen
	},
	{
		id: "favorites",
		label: "المفضلة",
		icon: Heart
	},
	{
		id: "topics",
		label: "التصنيفات",
		icon: LayoutGrid
	}
];
function BottomNav() {
	const tab = useQuotesStore((s) => s.tab);
	const setTab = useQuotesStore((s) => s.setTab);
	const activeIndex = TABS.findIndex((t) => t.id === tab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "التنقل",
		className: "relative mx-4 mb-4 mt-1 grid grid-cols-3 rounded-full border border-border bg-bg-elevated p-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "nav-pill",
			style: { insetInlineStart: `calc(${activeIndex * 33.333}% + 6px)` }
		}), TABS.map((item) => {
			const Icon = item.icon;
			const active = item.id === tab;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab(item.id),
				"aria-current": active ? "page" : void 0,
				className: cn("relative z-10 flex h-11 flex-col items-center justify-center gap-0.5 rounded-full text-xs font-medium transition-colors duration-150", active ? "text-fg" : "text-fg-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-4", active && item.id === "favorites" && "fill-mark text-mark") }), item.label]
			}, item.id);
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			solid: "bg-accent text-accent-fg",
			ghost: "bg-transparent text-fg hover:bg-bg-subtle border border-transparent",
			outline: "border border-border text-fg bg-transparent hover:bg-bg-subtle",
			paper: "bg-paper text-paper-fg",
			icon: "bg-bg-subtle text-fg border border-border-strong hover:bg-bg-elevated"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-3.5 text-xs",
			lg: "h-12 px-6",
			icon: "size-11",
			iconSm: "size-9"
		}
	},
	defaultVariants: {
		variant: "solid",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Spark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": "true",
		className: cn("spark", className)
	});
}
function StarMark({ className, tone = "accent" }) {
	const fill = tone === "paper" ? "var(--color-paper-fg)" : tone === "ink" ? "var(--color-fg)" : "var(--color-accent)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-4", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill,
			d: "M12 1.8 13.1 9 20.4 6.2 15.2 12 20.4 17.8 13.1 15 12 22.2 10.9 15 3.6 17.8 8.8 12 3.6 6.2 10.9 9Z"
		})
	});
}
function CornerFrame({ tone = "light" }) {
	const color = tone === "dark" ? "var(--color-paper-muted)" : "var(--color-fg-muted)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		"aria-hidden": "true",
		className: "pointer-events-none absolute inset-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "absolute start-0 top-0 size-3 border-s border-t",
				style: { borderColor: color }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "absolute end-0 top-0 size-3 border-e border-t",
				style: { borderColor: color }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "absolute start-0 bottom-0 size-3 border-s border-b",
				style: { borderColor: color }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "absolute end-0 bottom-0 size-3 border-e border-b",
				style: { borderColor: color }
			})
		]
	});
}
function FavoritesView() {
	const favorites = useQuotesStore((s) => s.favorites);
	const setTab = useQuotesStore((s) => s.setTab);
	const goTo = useQuotesStore((s) => s.goTo);
	const quotes = favorites.map(quoteById).filter((q) => Boolean(q));
	if (quotes.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-5 flex size-14 items-center justify-center rounded-full border border-border bg-bg-elevated",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-5 text-fg-muted" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-fg",
				children: "لا محفوظات بعد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-sm leading-normal text-fg-muted",
				children: "احفظ ما يلامسك من البطاقات، وتعود إليه هنا في أي وقت."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				onClick: () => setTab("feed"),
				children: "تصفّح الاقتباسات"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col px-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pb-4 pt-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-fg-muted",
				children: "محفوظاتك"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-2xl text-fg",
				children: "المفضلة"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "min-h-0 flex-1 space-y-3 overflow-y-auto pb-2",
			children: quotes.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => goTo(quote.id),
				className: "w-full rounded-xl border border-border bg-bg-elevated px-4 py-4 text-start transition-colors duration-150 hover:bg-bg-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-xs font-medium text-fg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: "size-1.5" }), CATEGORIES[quote.category].label]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-lg leading-snug text-fg",
						children: quote.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-fg-subtle",
						children: quote.author
					})
				]
			}) }, quote.id))
		})]
	});
}
var PAPER_SHAPES = /* @__PURE__ */ new Set(["paper", "window"]);
function QuoteCard({ quote, className }) {
	const shape = shapeFor(quote);
	const onPaper = PAPER_SHAPES.has(shape);
	const category = CATEGORIES[quote.category];
	const long = quote.text.length > 72;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("quote-shape", `quote-shape-${shape}`, className),
		"aria-label": `اقتباس لـ ${quote.author}`,
		children: [
			shape === "frame" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerFrame, {}) : null,
			shape === "mark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, {
				className: "mb-6 size-5",
				tone: "accent"
			}) : null,
			shape === "window" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: "mb-6" }) : null,
			shape === "paper" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mb-6 flex items-center gap-2 text-xs font-medium tracking-wide text-paper-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: "size-1.5 bg-paper-muted" }), category.label]
			}) : null,
			shape !== "paper" && shape !== "window" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mb-6 text-xs font-medium tracking-wide", onPaper ? "text-paper-muted" : "text-fg-muted"),
				children: category.label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("font-display leading-snug text-balance", long ? "text-xl" : shape === "ink" ? "text-3xl" : "text-2xl", onPaper ? "text-paper-fg" : "text-fg"),
				children: quote.text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mt-8 flex flex-col items-center gap-2", onPaper ? "text-paper-muted" : "text-fg-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block h-px w-8", onPaper ? "bg-paper-muted/50" : "bg-border-strong") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-sans text-sm font-medium",
					children: quote.author
				})]
			})
		]
	});
}
async function shareQuote(text, author, onCopied) {
	const payload = `«${text}»\n— ${author}\n\nقَبَس`;
	if (typeof navigator !== "undefined" && navigator.share) try {
		await navigator.share({
			title: "قَبَس",
			text: payload
		});
		return;
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") return;
	}
	try {
		await navigator.clipboard.writeText(payload);
		onCopied();
	} catch {
		onCopied();
	}
}
function QuoteFeed() {
	const index = useQuotesStore((s) => s.index);
	const favorites = useQuotesStore((s) => s.favorites);
	const category = useQuotesStore((s) => s.category);
	const next = useQuotesStore((s) => s.next);
	const prev = useQuotesStore((s) => s.prev);
	const shuffle = useQuotesStore((s) => s.shuffle);
	const toggleFavorite = useQuotesStore((s) => s.toggleFavorite);
	const showToast = useQuotesStore((s) => s.showToast);
	const feed = quotesByCategory(category);
	const current = feed.length === 0 ? null : feed[(index % feed.length + feed.length) % feed.length];
	const [dir, setDir] = (0, import_react.useState)("up");
	const [animKey, setAnimKey] = (0, import_react.useState)(0);
	const startY = (0, import_react.useRef)(null);
	const startX = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setAnimKey((k) => k + 1);
	}, [index]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "ArrowUp" || event.key === "ArrowRight") {
				event.preventDefault();
				setDir("up");
				next();
			}
			if (event.key === "ArrowDown" || event.key === "ArrowLeft") {
				event.preventDefault();
				setDir("down");
				prev();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [next, prev]);
	if (!current) return null;
	const liked = favorites.includes(current.id);
	const pos = `${index + 1} / ${feed.length}`;
	const label = category === "all" ? "كل الاقتباسات" : CATEGORIES[category].label;
	function onPointerDown(event) {
		startY.current = event.clientY;
		startX.current = event.clientX;
	}
	function onPointerUp(event) {
		if (startY.current == null || startX.current == null) return;
		const dy = event.clientY - startY.current;
		const dx = event.clientX - startX.current;
		startY.current = null;
		startX.current = null;
		if (Math.abs(dy) < 48 || Math.abs(dy) < Math.abs(dx)) return;
		if (dy < 0) {
			setDir("up");
			next();
		} else {
			setDir("down");
			prev();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between pt-1 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-fg-muted",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tabular-nums text-fg-subtle",
					children: pos
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex min-h-0 flex-1 touch-none items-center justify-center overflow-hidden",
				onPointerDown,
				onPointerUp,
				onPointerCancel: () => {
					startY.current = null;
					startX.current = null;
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex w-full items-center justify-center", dir === "up" ? "feed-enter-up" : "feed-enter-down"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteCard, { quote: current })
				}, animKey)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 pb-3 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "icon",
						size: "icon",
						"aria-label": "الاقتباس السابق",
						onClick: () => {
							setDir("down");
							prev();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "icon",
								size: "icon",
								"aria-label": "اقتباس عشوائي",
								onClick: () => {
									setDir("up");
									shuffle();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "icon",
								size: "icon",
								"aria-label": liked ? "إزالة من المفضلة" : "حفظ في المفضلة",
								onClick: () => toggleFavorite(current.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-5", liked && "fill-mark text-mark") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "icon",
								size: "icon",
								"aria-label": "مشاركة الاقتباس",
								onClick: () => void shareQuote(current.text, current.author, () => showToast("تم نسخ الاقتباس")),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-5" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "icon",
						size: "icon",
						"aria-label": "الاقتباس التالي",
						onClick: () => {
							setDir("up");
							next();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-5" })
					})
				]
			})
		]
	});
}
function TopicsView() {
	const category = useQuotesStore((s) => s.category);
	const setCategory = useQuotesStore((s) => s.setCategory);
	const allCount = quotesByCategory("all").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col px-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "pb-4 pt-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-fg-muted",
				children: "اختر مزاج البطاقة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-2xl text-fg",
				children: "التصنيفات"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in grid min-h-0 flex-1 grid-cols-1 gap-3 overflow-y-auto pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setCategory("all"),
				className: cn("flex items-center justify-between rounded-xl border px-5 py-5 text-start transition-colors duration-150", category === "all" ? "border-accent bg-paper text-paper-fg" : "border-border bg-bg-elevated text-fg hover:bg-bg-subtle"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 text-sm font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: cn("size-2", category === "all" ? "bg-paper-fg" : "bg-accent") }), "الكل"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("mt-1 block text-xs", category === "all" ? "text-paper-muted" : "text-fg-muted"),
					children: "كل الأشكال في موجة واحدة"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-sm",
					children: allCount
				})]
			}), CATEGORY_IDS.map((id) => {
				const meta = CATEGORIES[id];
				const count = quotesByCategory(id).length;
				const active = category === id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCategory(id),
					className: cn("flex items-center justify-between rounded-xl border px-5 py-5 text-start transition-colors duration-150", active ? "border-accent bg-paper text-paper-fg" : "border-border bg-bg-elevated text-fg hover:bg-bg-subtle"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: cn("size-2", active ? "bg-paper-fg" : "bg-accent") }), meta.label]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-1 block text-xs", active ? "text-paper-muted" : "text-fg-muted"),
						children: meta.hint
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-sm",
						children: count
					})]
				}, id);
			})]
		})]
	});
}
function AppShell() {
	const hydrate = useQuotesStore((s) => s.hydrate);
	const hydrated = useQuotesStore((s) => s.hydrated);
	const tab = useQuotesStore((s) => s.tab);
	const toast = useQuotesStore((s) => s.toast);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "phone-stage",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "phone-shell",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "phone-header flex items-center justify-center gap-2 px-5 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: "size-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl leading-tight tracking-wide text-fg",
						children: "قَبَس"
					})]
				}),
				!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-0 flex-1 items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { className: "size-3" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					tab === "feed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteFeed, {}) : null,
					tab === "favorites" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoritesView, {}) : null,
					tab === "topics" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicsView, {}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("toast-copy", toast && "is-on"),
					role: "status",
					"aria-live": "polite",
					"aria-hidden": toast ? void 0 : true,
					children: toast
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
